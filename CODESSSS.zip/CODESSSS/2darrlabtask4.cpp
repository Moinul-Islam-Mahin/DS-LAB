#include <iostream>
using namespace std;
int sum(int n,int arr[][99]){
    int countt = 0;
 for(int c=0; c<n;c++){
    countt=countt+ arr[0][c];
    countt=countt+arr[n-1][c];
 }
  for(int r=1; r<n-1;r++){
    countt=countt+ arr[r][0];
    countt=countt+arr[r][n-1];
 }
 return countt;
}
int main(){
int n = 0;
cout<<"enter your dimension : "<<endl;
cin>>n;
cout<<"enter your "<<n*n<<"elements "<<endl;
int MatA[99][99]={};
 for (int r=0; r<n;r++){
        for(int c=0; c<n;c++){
         cin>>MatA[r][c]; }
 }
 cout<<sum(n,MatA);
return 0;}
