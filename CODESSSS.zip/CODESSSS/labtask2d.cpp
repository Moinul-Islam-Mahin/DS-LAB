/*#include <iostream>
using namespace std;
int main(){
int n = 0;
cout<<"enter your dimension : "
cin>>n;





return 0;
}*/



#include <iostream>
using namespace std;

void sumarray(int arr1[2][2], int arr2[2][2], int result[2][2], int row, int col)
{
	for (int i = 0; i < row; i++)
		for (int j = 0; j < col; j++)
			result[i][j] = arr1[i][j] + arr2[i][j];
}

int main (){

	int mat1[2][2], mat2[2][2], sum[2][2];
	cout<<"Enter a 2x2 Matrix\n";
	for(int i=0; i<2; i++)
		for(int j=0; j<2; j++)
			cin>>mat1[i][j];
	cout<<"Enter another 2x2 Matrix\n";
	for(int i=0; i<2; i++)
		for(int j=0; j<2; j++)
			cin>>mat2[i][j];

	sumarray(mat1, mat2, sum, 2, 2);

	cout<<"Sum of Matrix:\n";
	for(int i=0; i<2; i++) {
		for(int j=0; j<2; j++)
			cout<<sum[i][j]<<" ";
		cout<<"\n";
	}

	return 0;
}
