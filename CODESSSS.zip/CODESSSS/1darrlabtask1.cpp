#include<iostream>
using namespace std;
int main (){
    int arr[2]={1,2};
    int ar[3]={3,4,5};
    int arraY[5]={};
    for (int i=0; i<2;i++){arraY[i]=arr[i];}
    for (int x=2,i=0; x<5,i<3;i++,x++){arraY[x]=ar[i];}
    for (int i=4; i>-1;i--){cout<<arraY[i]<<" ";}
    return 0;
}

