#include <iostream>
using namespace std;
class Array {
private:
    int size;
    int len;
    int *arr;

public:
    Array(int s) {
        size = s;
        len = 0;
        arr = new int[size];
        for (int i = 0; i < size; i++)
            arr[i] = 0;
    }

    Array(int s, int v) {
        size = s;
        len = s;
        arr = new int[size];
        for (int i = 0; i < size; i++)
            arr[i] = v;
    }

    void initArray(int v) {
        for (int i = 0; i < size; i++)
            arr[i] = v;
        len = size;
    }

    int getLength() {
        return len;
    }

    int at(int pos) {
        if (pos >= 0 && pos < len)
            return arr[pos];
        else {
            cout << "Invalid index!" << endl;
            return -1;
        }
    }

    bool isEmpty() {
        return len == 0;
    }

    bool isFull() {
        return len == size;
    }

    void print() {
        if (len == 0) {
            cout << "Array is empty!" << endl;
            return;
        }
        cout << "Array elements: ";
        for (int i = 0; i < len; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    void insert(int v) {
        if (len < size) {
            arr[len] = v;
            len++;
        } else {
            cout << "Array is full!" << endl;
        }
    }

    void insertAt(int pos, int v) {
        if (isFull()) {
            cout << "Array is full!" << endl;
            return;
        }
        if (pos < 0 || pos > len) {
            cout << "Invalid position!" << endl;
            return;
        }
        for (int i = len; i > pos; i--)
            arr[i] = arr[i - 1];
        arr[pos] = v;
        len++;
    }

    void replaceAt(int pos, int v) {
        if (pos >= 0 && pos < len)
            arr[pos] = v;
        else
            cout << "Invalid position!" << endl;
    }

    void remove() {
        if (len > 0)
            len--;
        else
            cout << "Array is empty!" << endl;
    }

    void removeAt(int pos) {
        if (pos < 0 || pos >= len) {
            cout << "Invalid position!" << endl;
            return;
        }
        for (int i = pos; i < len - 1; i++)
            arr[i] = arr[i + 1];
        len--;
    }

    void clear() {
        for (int i = 0; i < size; i++)
            arr[i] = 0;
        len = 0;
    }

    void reverseArray() {
        for (int i = 0; i < len / 2; i++) {
            int temp = arr[i];
            arr[i] = arr[len - i - 1];
            arr[len - i - 1] = temp;
        }
    }


    void copyArray(int data[], int n) {
        if (n > size) n = size;
        for (int i = 0; i < n; i++)
            arr[i] = data[i];
        len = n;
    }
    ~Array() {
        delete[] arr;
        cout << "Destructor called!" << endl;
    }
};
