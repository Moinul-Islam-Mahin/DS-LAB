#include<iostream>
using namespace std;
void mergeArra(int arr1[5], int arr2[4])
{

}



int main(){
int Arra_1[]= {10,20,30,40,50};
int Arra_2[]= {20,12,34,40};
return 0;
}
