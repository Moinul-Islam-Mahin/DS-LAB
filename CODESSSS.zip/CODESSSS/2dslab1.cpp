#include<iostream>
using namespace std;
void mergeArra(int x,int y, int arr1[], int arr2[])
{
int size= x+y;
int arr[size ];
for(int i=0;i<x; i++)
{
    arr[i]= arr1[i];
    cout<<arr[i]<<" ";
}
for(int i=x;i<size; i++)
{
    arr[i]= arr1[j];
    cout<<arr[i]<<" ";
}

}



int main(){
int Arra_1[5]= {10,20,30,40,50};
int Arra_2[4]= {20,12,34,40};
mergeArra(5,4,Arra_1,Arra_2);
return 0;
}
