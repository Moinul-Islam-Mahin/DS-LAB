#include <iostream>
using namespace std;

class Arr {
private:
    int size;
    int length;
    int* arr;

public:
    Arr(const int size) {
        this.size = size;
        length = 0;
        Arr = new int[size];
        for (int i = 0; i < size; i++)
            arr[i] = 0;
    }

    Arr(const int size, int v) {
        this.size = size;
        length = size;
        arr = new int[size];
        for (int i = 0; i < size; i++)
            arr[i] = v;
    }

    ~Arr() {
        delete[] arr;
    }

    void initArr(int v) {
        for (int i = 0; i < size; i++)
            arr[i] = v;
        length = size;
    }

    int getLength() const {
        return length;
    }

    bool isEmpty() const {
        return length == 0;
    }

    bool isFull() const {
        return length == size;
    }

    int at(int pos) const {
        if (pos < 0 || pos >= length) {
            cout << "Index out of range!" << endl;
            return -1;
        }
        return arr[pos];
    }

    void print() const {
        if (length == 0) {
            cout << "Array is empty!" << endl;
            return;
        }
        for (int i = 0; i < length; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    void insert(int v) {
        if (isFull()) {
            cout << "Array is full!" << endl;
            return;
        }
        arr[length++] = v;
    }

    void insertAt(int pos, int v) {
        if (isFull()) {
            cout << "Array is full!" << endl;
            return;
        }
        if (pos < 0 || pos > length) {
            cout << "Invalid position!" << endl;
            return;
        }
        for (int i = length; i > pos; i--)
            arr[i] = arr[i - 1];
        arr[pos] = v;
        length++;
    }

    void replaceAt(int pos, int v) {
        if (pos < 0 || pos >= length) {
            cout << "Invalid position!" << endl;
            return;
        }
        arr[pos] = v;
    }

    void remove() {
        if (isEmpty()) {
            cout << "Array is empty!" << endl;
            return;
        }
        arr[--length] = 0;
    }

    void removeAt(int pos) {
        if (pos < 0 || pos >= length) {
            cout << "Invalid position!" << endl;
            return;
        }
        for (int i = pos; i < length - 1; i++)
            arr[i] = arr[i + 1];
        arr[--length] = 0;
    }

    void clear() {
        for (int i = 0; i < size; i++)
            arr[i] = 0;
        length = 0;
    }

    void reverseArray() {
        for (int i = 0; i < length / 2; i++)
            swap(arr[i], arr[length - 1 - i]);
    }

    void copyArray(int data[], int n) {
        if (n > size) {
            cout << "Too many elements to copy!" << endl;
            return;
        }
        for (int i = 0; i < n; i++)
            arr[i] = data[i];
        length = n;
    }
};

