#include <iostream>
using namespace std;
int inMat(int arr[][2] )
{
    for (int r=0; r<2;r++){
        for(int c=0; c<2;c++){
         cin>>arr[r][c];
        }
    }
return arr[2][2];
}
int printMat(int arr[][2] )
{
    for (int r=0; r<2;r++){
        for(int c=0; c<2;c++){
         cout<<arr[r][c]<<" ";
        }cout<<endl;
    }
return arr[2][2];
}
void sum(int arr[][2],int arr1[][2], int arr3[][2] )
{
    for (int r=0; r<2;r++){
        for(int c=0; c<2;c++){
         arr3[r][c]=arr[r][c]+arr1[r][c];
         cout<<arr3[r][c]<<" ";
        }cout<<endl;
    }
}
int main(){
int MatA[2][2]={};
int MatB[2][2]={};
int MatAns[2][2]={};
cout<<"enter your first 2X2 matrix : ";
inMat(MatA);
cout<<"enter your second 2X2 matrix : ";
inMat(MatB);
printMat(MatA);
printMat(MatB);
sum(MatA,MatB,MatAns);
return 0;
}

