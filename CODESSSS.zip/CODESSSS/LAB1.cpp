#include <iostream>
using namespace std;
int main(){
int arr[10];
for (int x=0;x<10;x++){
    cin>>arr[x] ;}

for (int x=0;x<10;x++){
    cout<<arr[x]<<" ";}
for (int x=9;x>-1;x--){
    cout<<arr[x]<<" " ;}

return 0;
}
