#include <iostream>
using namespace std;
int main(){
int arr[10];
for (int x=0;x<10;x++){
    cin>>arr[x] ;}
int w=0;
int z=0;
for(int x=0;x<10;x++)
{
    if (arr[x]%2==0)
    {
        w++;
    }
    else {
       z++;
    }
}
cout<<w<<"even numbers"<<endl<<z<<"odd numbers"<<endl;

return 0;
}
