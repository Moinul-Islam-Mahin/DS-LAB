#include <iostream>
using namespace std;
void Fac(int x)
{
 if (x > 1) && {for(int i=2;i<=x/2;i++)}{
 if(x%int i==0){
 int z=x;
    for(int a=x-1; a>0; a--)
    {
     z=z*a;
    }
    cout<<z;
}}
else {cout<<"not a prime number ";}
 }
int main(){
int x;
cin>>x;
Fac(x);
return 0;}
