#include <iostream>
using namespace std;
void iMat(int mat[3][3]) {
    cout << "Enter elements of matrix " << endl;
    for (int i = 0; i < 3; i++) {
for (int j = 0; j < 3; j++) {
        cin >> mat[i][j];}
}}
void mMat(int A[3][3], int B[3][3], int M[3][3]) {
   for (int i = 0; i < 3; i++) {
for (int j = 0; j < 3; j++) {
    for (int k = 0; k < 3; k++) {
        M[i][j] += A[i][k] * B[k][j];
            } cout<<M[i][j]<<" ";
}cout<<endl;}}
int main() {
    int A[3][3], B[3][3], M[3][3]={};
    iMat(A);
    iMat(B);
    mMat(A, B, M);
    return 0;
}


