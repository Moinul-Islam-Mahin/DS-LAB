#include<iostream>
using namespace std;

void check(int n,int A[10]){
    int countt=0;
    for(int i=0;i<10;i++)
    {
        if (n==A[i]){countt=countt+1;}
    }

cout<<n<<" occurs = " <<countt<<"times"<<endl;
}
int main (){
    int A[10]={1,2,3,4,5,6,7,7,8,2};
 check(1,A);
 check(2,A);
 check(3,A);
 check(4,A);
 check(5,A);
 check(6,A);
 check(7,A);
 check(8,A);

    return 0;
}
