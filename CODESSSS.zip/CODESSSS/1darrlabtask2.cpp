#include <iostream>
using namespace std;
int main() {
    int A[7] = {1, 4, 6, 3, 7, 9,1};
    int B[7] = {};
    int k = 0;
   int countt=0;
    for (int i = 0; i < 7; i++) {
        int j;
        for (j = 0; j < k && A[i] != B[j]; j++);
        if (j < k)
           countt=countt+1;
        else
           {B[k] = A[i];k++;}
    }
    if (countt==0)
    cout << "Array already unique!" << endl;
    else {
cout << "Unique elements: ";
        for (int i = 0; i < k; i++)
            cout << B[i] << " ";
    cout << endl;
    }
    return 0;
}
