#include <iostream>
using namespace std;
class Array {
private:
    int size;
    int length;
    int *arr;
public:
    Array(const int s) {
        size = s;
        length = 0;
        arr = new int[size];
        for (int i = 0; i < size; i++)
            {arr[i] = 0;}
    }

    Array(const int s, int v) {
        size = s;
        length = s;
        arr = new int[size];
        for (int i = 0; i < size; i++)
            arr[i] = v;
    }

    void initArray(int v) {
        for (int i = 0; i < size; i++)
           {arr[i] = v;}
        length = size;
    }

   int getLength() {
    return length;
}


    int at(int pos) {
        if (pos >= 0 && pos < length)
            return arr[pos];
        else {
            cout << "Invalid index!" << endl;
            return -1;
        }
    }

    bool isEmpty() {
        return length == 0;
    }

    bool isFull() {
        return length == size;
    }

    void print() {
        if (length == 0) {
            cout << "Array is empty!" << endl;
            return;
        }
        cout << "Array elements: ";
        for (int i = 0; i < length; i++)
            cout << arr[i] << " ";
        cout << endl;
    }

    void insert(int v) {
        if (length < size) {
            arr[length] = v;
            length++;
        } else {
            cout << "Array is full!" << endl;
        }
    }

    void insertAt(int pos, int v) {
        if (isFull()) {
            cout << "Array is full!" << endl;
            return;
        }
        if (pos < 0 || pos > length) {
            cout << "Invalid position!" << endl;
            return;
        }
        else{
        for (int i = length; i > pos; i--)
            arr[i] = arr[i - 1];
        arr[pos] = v;
        length++;}
    }

    void replaceAt(int pos, int v) {
        if (pos >= 0 && pos < length)
            arr[pos] = v;
        else
            cout << "Invalid position!" << endl;
    }

    void remove() {
        if (length > 0)
            length--;
        else
            cout << "Array is empty!" << endl;
    }

    void removeAt(int pos) {
        if (pos < 0 || pos >= length) {
            cout << "Invalid position!" << endl;
            return;
        }
        for (int i = pos; i < length - 1; i++)
            {arr[i] = arr[i + 1];}
        length--;
    }

    void clear() {
        for (int i = 0; i < size; i++)
            arr[i] = 0;
        length = 0;
    }

    void reverseArray() {
        for (int i = 0; i < length / 2; i++) {
            int temp = arr[i];
            arr[i] = arr[length - i - 1];
            arr[length - i - 1] = temp;
        }
    }


    void copyArray(int data[], int n) {
        if (n > size) {n = size;}
        for (int i = 0; i < n; i++)
            arr[i] = data[i];
        length = n;
    }
    ~Array() {
        delete[] arr;
        cout << "Destructor called!" << endl;
    }
};
