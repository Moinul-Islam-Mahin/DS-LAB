#include <iostream>
using namespace std;

int main ()
{ int n=0;
cout<<"enter your odd number to create a magic square : "<<endl;
cin>>n;
if(n%2==0){cout<<"the number is not odd"<<endl;}
else{
   int** msq=new int*[n];
   int i, j, x;
   int row = 0;
   int col = n/ 2;
   for ( i = 0; i < n ; i++ )
   { msq[i] = new int[n];

      for ( j = 0 ; j < n; j++ ) msq[i][j] = 0;
   }
 msq[row][col] = 1;
   for ( x = 2; x <= n * n; x++ )
   {
      int r = row - 1, c = col - 1;
      if (r < 0) r += n;
      if (c < 0) c += n;
      if ( msq[r][c]>0)
      {
         row++;
         if ( row >= n ) row -= n;
      }
      else
      {
         row = r;
         col = c;
      }
      msq[row][col] = x;
   }
   for ( i = 0; i < n; i++ )
   {
      for ( j = 0; j < n; j++ ) cout << msq[i][j] << " ";
      cout<<endl;
   }}
   return 0;}
