#include <iostream>
using namespace std;
int sum(int n,int arr[][99]){
    int countt = 0;
    for (int r=0; r<n;r++){
    for(int c=n-1; c>-1;c--){
   if(r==c || r+c == n-1){countt = countt + arr[r][c];}
         }
}
return countt;}
int main(){
int n = 0;
cout<<"enter your dimension : "<<endl;
cin>>n;
cout<<"enter your "<<n*n<<"elements "<<endl;
int MatA[99][99]={};
 for (int r=0; r<n;r++){
        for(int c=0; c<n;c++){
         cin>>MatA[r][c]; }
 }
 cout<<sum(n,MatA);
return 0;}
