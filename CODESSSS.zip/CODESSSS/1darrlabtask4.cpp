#include<iostream>
using namespace std;
int main (){
    int A[10]={1,2,3,4,5,6,7,7,8,2};
    cout<<"enter integer to check : "<<endl;
    int n=0;
    cin>>n;
    int countt=0;
    for(int x=0;x<10;x++){
            if(n==A[x]){countt=countt+1;}
}
cout<<"The number occurs "<<countt<<" times in the array";
    return 0;
}

