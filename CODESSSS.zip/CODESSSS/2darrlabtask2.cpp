#include <iostream>
using namespace std;
void trans(int n,int arr[][99],int arr1[][99]){
    for (int r=0; r<n;r++){
        for(int c=0; c<n;c++){
                arr1[r][c]=arr[c][r];
                cout<<arr1[r][c]<<" ";
         }cout<<endl;
}}
int main(){
int n = 0;
cout<<"enter your dimension : "<<endl;
cin>>n;
cout<<"enter your "<<n*n<<"elements "<<endl;
int MatA[99][99]={};
int MatTr[99][99]={};
 for (int r=0; r<n;r++){
        for(int c=0; c<n;c++){
         cin>>MatA[r][c]; }
 }
 trans(n,MatA,MatTr);

return 0;}
