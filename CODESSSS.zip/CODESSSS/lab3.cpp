#include <iostream>
using namespace std;

void func(int x, int y){
for (int i=x; i<=y ; i++){
if (i%2==!0){cout<<i<<"  ";}
}
}

int main(){
    int StValue, endValue;
    cout<<"enter your starting and then ending value"<<endl;
cin>>StValue>>endValue;
func(StValue,endValue);

return 0;
}
