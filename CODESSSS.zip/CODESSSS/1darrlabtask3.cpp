#include<iostream>
using namespace std;
int main (){
    int A[7]={1,2,3,4,5,6,7};
    int B[8]={9,10,20,30,40,5,60,70};
    int C[8]={};
    int z=0;
    for(int i=0;i<7;i++){for(int j=0;j<8;j++){
        if(A[i]==B[j]){C[z]=B[j];
        z++;}
    }}
if (z!=0){
for(int x=0;x<z;x++){cout<<C[x]<<" ";}}
else{ cout<<"no common elements";}
    return 0;
}

