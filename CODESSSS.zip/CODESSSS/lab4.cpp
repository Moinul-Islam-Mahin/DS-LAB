#include <iostream>
using namespace std;
void MatAd(int a[3][3], int b[3][3],int c[3][3])
{
int S[3][3];
for(int i=0; i<3;i++)
    {for(int j=0; j<3;j++){
S[i][j] = a[i][j] + b[i][j] + c[i][j];
            cout << S[i][j] << " ";}
cout<<endl;}
}
void MatIn(int a[3][3],int b[3][3],int c[3][3])
{
  for(int i=0; i<3;i++)
    {for(int j=0; j<3;j++){cin>>a[i][j];}}

    for(int i=0; i<3;i++)
    {for(int j=0; j<3;j++){cin>>b[i][j];}}

    for(int i=0; i<3;i++)
    {for(int j=0; j<3;j++){cin>>c[i][j];}}

}


int main(){
int a[3][3],b[3][3],c[3][3];
MatIn(a,b,c);
MatAd(a,b,c);
return 0;
}
